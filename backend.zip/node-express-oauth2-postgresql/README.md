# REST API Security with Node-Express-PostgreSQL-Oauth2 

This source code is part of [REST API Security with Node-Express-PostgreSQL-Oauth2](https://www.djamware.com/post/5f808519b9ebd3190382a52f/rest-api-security-with-node-express-postgresql-oauth2) tutorial.
