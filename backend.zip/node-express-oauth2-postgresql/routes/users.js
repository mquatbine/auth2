// routes/users.js
const express = require('express');
const router  = express.Router();

// Import your Sequelize models:
const db = require('../models');            // Adjust path if your models folder is elsewhere
const { OAuthUsers } = db;

/* GET users listing. */
router.get('/', async function(req, res, next) {
  try {
    // Select only the fields you want to expose
    const users = await OAuthUsers.findAll({
      attributes: ['id','username','name','createdAt']
    });
    res.json(users);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
