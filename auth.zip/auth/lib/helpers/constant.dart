class Constants {
  Constants._();
  static const baseUrl = 'http://192.168.11.139:3000';
}
